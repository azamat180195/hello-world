package com.progressive.code.starter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NginxLoggerExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(NginxLoggerExampleApplication.class, args);
	}
}
