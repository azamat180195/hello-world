package com.progressive.code.crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by abraun on 10/11/2017.
 */
@SpringBootApplication
public class CrudApp {

    public static void main(String[] args) {
        SpringApplication.run(CrudApp.class, args);
    }

}
