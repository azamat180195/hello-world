# Properties Example
This project consists of a simple commandline Spring Boot application that shows how to read files from the resource folder correctly.

Detailed explanations about the project can be found here: 

https://progressive-code.com/post/7/How-to-read-a-file-from-the-resources-folder-in-a-Spring-Boot-application

## Build the project

```
mvn package
```

## Run the project

```
java -jar target/PropertiesDemo-0.0.1-SNAPSHOT.jar
```
